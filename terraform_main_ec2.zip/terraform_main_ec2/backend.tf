terraform {
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }

  backend "s3" {
    bucket         = "my-eks-terraform-state-302524629943-us-east-1"
    key            = "env/terraform.tfstate"   # ✅ FIXED
    region         = "us-east-1"
    dynamodb_table = "terraform-locks"
    encrypt        = true
  }
}